﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace OV7670_Terminal
{
    class SccbRegister
    {
        private readonly byte _myAddress;
        public RegisterValue Value { get; set; }

        public SccbRegister(byte sAddress){
            _myAddress = sAddress;
            Value = new RegisterValue();
        }
        public SccbRegister(byte sAddress, RegisterValue sValue){
            _myAddress = sAddress;
            Value = sValue;
        }

        public byte MyAddress
        {
            get { return _myAddress; }
        }

        public override string ToString()
        {
            var output = _myAddress.ToString() + ";" + Value.toString();
            return output;
        }

        public string ToStringHex()
        {
            var output = string.Format("{0:X}", _myAddress) + "\t" + string.Format("{0:X}", Value.getByte());
            return output;
        }

        protected bool Equals(SccbRegister other)
        {
            return _myAddress == other._myAddress;
        }
        
    }
}
