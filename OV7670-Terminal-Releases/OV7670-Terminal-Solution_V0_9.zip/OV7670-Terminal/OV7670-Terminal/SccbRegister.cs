﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace OV7670_Terminal
{
    class SccbRegister
    {
        private readonly byte _myAddress;
        public RegisterValue Value { get; set; }

        public SccbRegister(byte sAddress){
            _myAddress = sAddress;
            Value = new RegisterValue();
        }
        public SccbRegister(byte sAddress, RegisterValue sValue){
            _myAddress = sAddress;
            Value = sValue;
        }

        public byte MyAddress
        {
            get { return _myAddress; }
        }

        public override string ToString()
        {
            var output = _myAddress.ToString() + ";" + Value.toString();
            return output;
        }

        public string ToStringHex()
        {
            var output = "0x"+string.Format("{0:X2}", _myAddress) + "\t" + "0x"+string.Format("{0:X2}", Value.getByte());
            return output;
        }

        public string ToStringHexCSV()
        {
            var output = "0x" + string.Format("{0:X2}", _myAddress) + ";" + "0x" + string.Format("{0:X2}", Value.getByte());
            return output;
        }

        public string ToStructHex()
        {
            var output ="{ "+ "0x" + string.Format("{0:X2}", _myAddress) + ", " + "0x" + string.Format("{0:X2}", Value.getByte()) + " },";
            return output;

        }

        public bool AddAndValueEquals(SccbRegister other)
        {
            if ((_myAddress == other._myAddress) && (Value.getByte() == other.Value.getByte()))
                return true;
            else
                return false;
            
        }
        
    }
}
